﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace mustafa
{
    public partial class Form3 : Form
    {
        SqlConnection conncrtion;
        public Form3(SqlConnection con)
        {
            InitializeComponent();
            conncrtion = con;
        }
        private void accept(object sender, EventArgs e)
        {
            conncrtion.Open();
            SqlCommand cmd = new SqlCommand("update users set access=1 where id=" + ((Button)sender).Name + "", conncrtion);
            cmd.ExecuteNonQuery();
            conncrtion.Close();
            MessageBox.Show("تمت الموافقة على الاضافة");
            Form3 f = new Form3(conncrtion);
            this.Hide();
            f.Show();
        }

        private void dirct(object sender, EventArgs e)
        {
            Form5 f = new Form5(conncrtion, ((Button)sender).Name);
            f.ShowDialog();
            Form3 ff = new Form3(conncrtion);
            this.Hide();
            ff.Show();
        }

        void getApps()
        {
            conncrtion.Open();
            SqlCommand cmd = new SqlCommand("select * from apps where state=N'التوكيل'", conncrtion);
            SqlDataReader reader = cmd.ExecuteReader();
            int y = 30;
            int x = 30;
            Button button;
            while (reader.Read())
            {
                button = new Button();
                string title = "اسم القضية: " + reader[1].ToString() + "\r\nنوع القضية:" + reader[2].ToString() + "\r\nاسم الموكل:" + reader[3].ToString() + "\r\nالتاريخ:" + reader[5].ToString();
                button.Text = title;
                button.Name = reader[0].ToString();
                button.Width = 150;
                button.Height = 60;
                button.Top = y;
                button.Left = x;
                x += 160;
                if (x > tabPage1.Width)
                {
                    y += 70;
                    x = 30;
                }

                button.Click += dirct;
                tabPage1.Controls.Add(button);
            }
            reader.Close();
            conncrtion.Close();
        }

        void getUsers()
        {
            conncrtion.Open();
            SqlCommand cmd = new SqlCommand("select id,username,name from users where access=0", conncrtion);
            SqlDataReader reader = cmd.ExecuteReader();
            int y = 30;
            int x = 30;
            Button button;
            while (reader.Read())
            {
                string s = "اسم المستخدم:" + reader[1].ToString() + "\r\nالاسم:" + reader[2].ToString();
                button = new Button();
                button.Text = reader[1].ToString() + " | " + reader[2].ToString();
                button.Name = reader[0].ToString();
                button.Width = 100;
                button.Height = 30;
                button.Left = x;
                button.Top = y;
                x += 110;
                if (x > tabPage2.Width)
                    y += 40;
                button.Click += accept;
                tabPage2.Controls.Add(button);
            }
            reader.Close();
            conncrtion.Close();
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            getApps();
            getUsers();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form9 f = new Form9();
            this.Hide();
            f.Show();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form9 f = new Form9();
            this.Hide();
            f.Show();
        }
    }
}
