﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace mustafa
{
    public partial class Form2 : Form
    {
        SqlConnection conection;
        public Form2(SqlConnection con)
        {
            InitializeComponent();
            conection = con;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            conection.Open();
            SqlCommand cmd = new SqlCommand("insert into users values('" + textBox1.Text + "','" + textBox2.Text + "',N'" + textBox3.Text + "'," + comboBox1.SelectedIndex + ",0)", conection);
            cmd.ExecuteNonQuery();
            conection.Close();
            MessageBox.Show("تم التسجيل بنجاح انظر موافقة المدير");
        }
    }
}
