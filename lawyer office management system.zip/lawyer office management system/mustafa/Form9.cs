﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace mustafa
{
    public partial class Form9 : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=" + System.IO.Path.GetFullPath(@"..\..\") + "Database1.mdf;Integrated Security=True");

        public Form9()
        {
            InitializeComponent();
        }

        private void Form9_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand cmd = new SqlCommand("select * from users where username='" + textBox1.Text + "' and access=1", connection);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                if (reader[2].ToString().Equals(textBox2.Text))
                {

                    string id = reader[0].ToString();
                    if (reader[4].ToString().Equals("0"))
                    {
                        connection.Close();
                        Form3 f = new Form3(connection);
                        this.Hide();
                        f.Show();
                    }
                    else if (reader[4].ToString().Equals("1"))
                    {
                        connection.Close();
                        Form6 f = new Form6(connection, id);
                        this.Hide();
                        f.Show();
                    }
                    else if (reader[4].ToString().Equals("2"))
                    {
                        connection.Close();
                        Form7 f = new Form7(connection, id);
                        this.Hide();
                        f.Show();
                    }
                    else
                    {
                        connection.Close();
                        Form4 f = new Form4(connection);
                        this.Hide();
                        f.Show();
                    }
                }
                else
                {
                    MessageBox.Show("كلمة المرور او اسم المستخدم غير صحيحات");
                }
            }
            else
            {
                MessageBox.Show("كلمة المرور او اسم المستخدم غير صحيحات");
            }
            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2(connection);
            f.ShowDialog();
        }
    }
}
