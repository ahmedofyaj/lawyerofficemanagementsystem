﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
namespace mustafa
{
    public partial class Form4 : Form
    {
        string today = DateTime.Today.Year.ToString() + " / " + DateTime.Today.Month.ToString() + " / " + DateTime.Today.Day.ToString();
        SqlConnection connection;
        string card1 = "";
        string card2 = "";
        string pic = "";
        public Form4(SqlConnection con)
        {
            InitializeComponent();
            connection = con;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            byte[] bcard1 = File.ReadAllBytes(card1);
            byte[] bcard2 = File.ReadAllBytes(card2);
            byte[] bpic = File.ReadAllBytes(pic);

            connection.Open();
            SqlCommand cmd = new SqlCommand("insert into apps values (N'" + textBox1.Text + "',N'" + comboBox1.Text + "',N'" + textBox3.Text + "',N'" + textBox4.Text + "',N'" + today + "',N'التوكيل',N'" + today + "',N'" + textBox5.Text + "',@card1,@card2,@pic)", connection);
            cmd.Parameters.Add(new SqlParameter("@card1", bcard1));
            cmd.Parameters.Add(new SqlParameter("@card2", bcard2));
            cmd.Parameters.Add(new SqlParameter("@pic", bpic));
            cmd.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("تمت الاضافة بنجاح");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            connection.Open();
            SqlDataAdapter adpt = new SqlDataAdapter("select * from apps where clintName like N'%" + textBox6.Text + "%'", connection);
            DataTable table = new DataTable();
            adpt.Fill(table);
            dataGridView1.DataSource = table;
            connection.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            connection.Open();
            SqlDataAdapter adpt = new SqlDataAdapter("select * from apps", connection);
            DataTable table = new DataTable();
            adpt.Fill(table);
            dataGridView1.DataSource = table;
            connection.Close();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            button3_Click(sender, e);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form9 f = new Form9();
            this.Hide();
            f.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
            card1 = ofd.FileName;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
            card2 = ofd.FileName;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
            pic = ofd.FileName;
        }
    }
}
