﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;
namespace mustafa
{
    class app
    {
        public string id;
        public string name;
        public string type;
        public string clintName;
        public string againstName;
        public string date;
        public string state;
        public string lastUpdate;
        public string nots;
        public byte[] card1;
        public byte[] card2;
        public byte[] pic;

        public Image getCard1()
        {
            if (card1 == null)
            {
                return null;
            }
            else
            {
                MemoryStream mstr = new MemoryStream(card1);
                Image image = Image.FromStream(mstr);
                return image;
            }
        }

        public Image getCard2()
        {
            if (card2 == null)
            {
                return null;
            }
            else
            {
                MemoryStream mstr = new MemoryStream(card2);
                Image image = Image.FromStream(mstr);
                return image;
            }
        }

        public Image getPic()
        {
            if (pic == null)
            {
                return null;
            }
            else
            {
                MemoryStream mstr = new MemoryStream(pic);
                Image image = Image.FromStream(mstr);
                return image;
            }
        }
    }
}
