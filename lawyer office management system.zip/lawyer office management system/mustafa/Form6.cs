﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace mustafa
{
    public partial class Form6 : Form
    {
        SqlConnection connection;
        string ID;
        List<app> apps;
        int count = 0;
        void show(app a)
        {
            label1.Text = a.id;
            label2.Text = a.name;
            label3.Text = a.type;
            label4.Text = a.clintName;
            label5.Text = a.againstName;
            label6.Text = a.date;
            label7.Text = a.lastUpdate;

            textBox1.Text = a.nots;
            textBox2.Text = a.state;

            pictureBox1.Image = a.getCard1();
            pictureBox2.Image = a.getCard2();
            pictureBox3.Image = a.getPic();
        }

        public Form6(SqlConnection con, string id)
        {
            InitializeComponent();
            connection = con;
            ID = id;
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand cmd = new SqlCommand("select * from applawer where lawer_id=" + ID + "", connection);
            SqlDataReader reader = cmd.ExecuteReader();
            List<string> IDs = new List<string>();
            while (reader.Read())
            {
                IDs.Add(reader[1].ToString());
            }
            reader.Close();
            connection.Close();

            apps = new List<app>();
            for (int i = 0; i < IDs.Count; i++)
            {
                connection.Open();
                cmd = new SqlCommand("select * from apps where id=" + IDs[i] + "", connection);
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    app a = new app();
                    a.id = reader[0].ToString();
                    a.name = reader[1].ToString();
                    a.type = reader[2].ToString();
                    a.clintName = reader[3].ToString();
                    a.againstName = reader[4].ToString();
                    a.date = reader[5].ToString();
                    a.state = reader[6].ToString();
                    a.lastUpdate = reader[7].ToString();
                    a.nots = reader[8].ToString();
                    a.card1 = (byte[])reader[9];
                    a.card2 = (byte[])reader[10];
                    a.pic = (byte[])reader[11];
                    apps.Add(a);
                }
                connection.Close();
            }
            if (apps.Count > 0)
            {
                show(apps[0]);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand cmd = new SqlCommand("update app set state=N'" + textBox2.Text + "' , nots=N'" + textBox1.Text + "' where id=" + label1.Text + " ", connection);
            cmd.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("تم الحذف");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("الحذف", "هل انت متاكد من حذف", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("delete from apps where id=" + label1.Text + "", connection);
                cmd.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show("تم الحذف");
                if (apps.Count > 0)
                {
                    show(apps[0]);
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            count = apps.Count - 1;
            show(apps[count]);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (count < apps.Count - 1)
            {
                count += 1;
            }
            show(apps[count]);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (count > 0)
            {
                count -= 1;
            }
            show(apps[count]);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            count = 0;
            show(apps[count]);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string num = Microsoft.VisualBasic.Interaction.InputBox("عرض قيد محدد", "رقم القيد", "0");
                count = int.Parse(num);
                if (count >= 0 && count < apps.Count)
                {

                    show(apps[count]);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form9 f = new Form9();
            this.Hide();
            f.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form8 f = new Form8(connection, apps[count].id);
            f.ShowDialog();
        }
    }
}
