﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace mustafa
{
    public partial class Form5 : Form
    {
        SqlConnection connection;
        string ID;
        List<string> IDsL = new List<string>();
        List<string> IDsAL = new List<string>();
        public Form5(SqlConnection con, string id)
        {
            InitializeComponent();
            connection = con;
            ID = id;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd;
            //MessageBox.Show(ID.ToString() + " " + treeView1.Nodes.Count.ToString() + " " + treeView2.Nodes.Count.ToString());
            for (int i = 0; i < treeView1.Nodes.Count; i++)
            {
                if (treeView1.Nodes[i].Checked == true)
                {
                    connection.Open();
                    cmd = new SqlCommand("insert into appLawer values (" + ID + "," + IDsL[i] + ")", connection);
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
                if (treeView2.Nodes.Count > i)
                {
                    if (treeView2.Nodes[i].Checked == true)
                    {
                        connection.Open();
                        cmd = new SqlCommand("insert into appLawer values (" + ID + "," + IDsAL[i] + ")", connection);
                        cmd.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }
            connection.Open();
            cmd = new SqlCommand("update apps set state=N'البداية' where id=" + ID + "", connection);
            cmd.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("تم التوكيل");
            this.Hide();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand cmd = new SqlCommand("select id,name from users where type=1", connection);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                treeView1.Nodes.Add(reader[1].ToString());
                IDsL.Add(reader[0].ToString());
            }
            reader.Close();
            connection.Close();

            connection.Open();
            cmd = new SqlCommand("select id,name from users where type=2", connection);
            reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                treeView2.Nodes.Add(reader[1].ToString());
                IDsAL.Add(reader[0].ToString());
            }
            reader.Close();
            connection.Close();
        }
    }
}