﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace mustafa
{
    public partial class Form8 : Form
    {
        SqlDataAdapter adapter;
        public Form8(SqlConnection con, string ID)
        {
            adapter = new SqlDataAdapter("select * from apps where id=" + ID + "", con);
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            Database1DataSet.Reset();
            adapter.Fill(this.Database1DataSet.apps);
            this.reportViewer1.RefreshReport();
        }
    }
}
